﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TaskPaneView
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn_RefreshSheets = New System.Windows.Forms.Button()
        Me.btn_ShowAllSheets = New System.Windows.Forms.Button()
        Me.listbox_shts = New System.Windows.Forms.CheckedListBox()
        Me.btn_HideAllSheets = New System.Windows.Forms.Button()
        Me.btn_SortSheets = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_RefreshSheets
        '
        Me.btn_RefreshSheets.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_RefreshSheets.Location = New System.Drawing.Point(27, 85)
        Me.btn_RefreshSheets.Name = "btn_RefreshSheets"
        Me.btn_RefreshSheets.Size = New System.Drawing.Size(107, 50)
        Me.btn_RefreshSheets.TabIndex = 3
        Me.btn_RefreshSheets.Text = "Refresh"
        Me.btn_RefreshSheets.UseVisualStyleBackColor = True
        '
        'btn_ShowAllSheets
        '
        Me.btn_ShowAllSheets.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ShowAllSheets.Location = New System.Drawing.Point(17, 19)
        Me.btn_ShowAllSheets.Name = "btn_ShowAllSheets"
        Me.btn_ShowAllSheets.Size = New System.Drawing.Size(126, 50)
        Me.btn_ShowAllSheets.TabIndex = 1
        Me.btn_ShowAllSheets.Text = "Show All"
        Me.btn_ShowAllSheets.UseVisualStyleBackColor = True
        '
        'listbox_shts
        '
        Me.listbox_shts.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.listbox_shts.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.listbox_shts.CheckOnClick = True
        Me.listbox_shts.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listbox_shts.FormattingEnabled = True
        Me.listbox_shts.HorizontalScrollbar = True
        Me.listbox_shts.Location = New System.Drawing.Point(17, 148)
        Me.listbox_shts.Margin = New System.Windows.Forms.Padding(3, 10, 3, 3)
        Me.listbox_shts.Name = "listbox_shts"
        Me.listbox_shts.Size = New System.Drawing.Size(244, 33)
        Me.listbox_shts.TabIndex = 4
        '
        'btn_HideAllSheets
        '
        Me.btn_HideAllSheets.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_HideAllSheets.Location = New System.Drawing.Point(153, 19)
        Me.btn_HideAllSheets.Name = "btn_HideAllSheets"
        Me.btn_HideAllSheets.Size = New System.Drawing.Size(126, 50)
        Me.btn_HideAllSheets.TabIndex = 5
        Me.btn_HideAllSheets.Text = "Hide All"
        Me.btn_HideAllSheets.UseVisualStyleBackColor = True
        '
        'btn_SortSheets
        '
        Me.btn_SortSheets.Enabled = False
        Me.btn_SortSheets.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SortSheets.Location = New System.Drawing.Point(163, 85)
        Me.btn_SortSheets.Name = "btn_SortSheets"
        Me.btn_SortSheets.Size = New System.Drawing.Size(107, 50)
        Me.btn_SortSheets.TabIndex = 6
        Me.btn_SortSheets.Text = "Sort"
        Me.btn_SortSheets.UseVisualStyleBackColor = True
        '
        'TaskPaneView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Controls.Add(Me.btn_SortSheets)
        Me.Controls.Add(Me.btn_HideAllSheets)
        Me.Controls.Add(Me.listbox_shts)
        Me.Controls.Add(Me.btn_ShowAllSheets)
        Me.Controls.Add(Me.btn_RefreshSheets)
        Me.Name = "TaskPaneView"
        Me.Size = New System.Drawing.Size(300, 269)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_RefreshSheets As Windows.Forms.Button
    Friend WithEvents btn_ShowAllSheets As Windows.Forms.Button
    Friend WithEvents listbox_shts As Windows.Forms.CheckedListBox
    Friend WithEvents btn_HideAllSheets As Windows.Forms.Button
    Friend WithEvents btn_SortSheets As Windows.Forms.Button
End Class
