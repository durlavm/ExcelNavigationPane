﻿Imports Microsoft.Office.Tools


Public Class ThisAddIn
    Private insTaskPane As CustomTaskPane

    Friend ReadOnly Property TaskPaneProp As CustomTaskPane
        Get
            Return Me.insTaskPane
        End Get
    End Property

    Public Sub ThisAddIn_Startup(ByVal sender As Object,
    ByVal e As System.EventArgs) Handles Me.Startup
        Dim insTaskPaneForm = New TaskPaneView
        insTaskPane = Me.CustomTaskPanes.Add(insTaskPaneForm, "Sheets", Me.Application.ActiveWindow)
        With insTaskPane
            .DockPosition = Office.MsoCTPDockPosition.msoCTPDockPositionFloating
            .Height = 500
            .Width = 400
            .DockPosition = Office.MsoCTPDockPosition.msoCTPDockPositionLeft
            .Width = 300
            .Visible = True
        End With
        insTaskPaneForm.SyncSheets()
    End Sub

    Private Sub ThisAddIn_Shutdown() Handles Me.Shutdown

    End Sub

End Class