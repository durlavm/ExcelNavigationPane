﻿Imports Microsoft.Office.Tools.Ribbon
Imports Microsoft.Office.Tools

Public Class TaskPaneRibbon
    Private insTaskPane As CustomTaskPane
    Private existingTaskPane As TaskPaneView

    Friend Sub chkBx_Rbn_TskPane_Click(ByVal sender As Object, ByVal e As RibbonControlEventArgs) Handles chkBx_Rbn_TskPane.Click
        If chkBx_Rbn_TskPane.Checked = True Then
            Globals.ThisAddIn.TaskPaneProp.Visible = True
        Else
            Globals.ThisAddIn.TaskPaneProp.Visible = False
        End If
    End Sub

    Private Sub btn_NavPane_Click(sender As Object, e As RibbonControlEventArgs) Handles btn_NavPane.Click

        ' If Globals.ThisAddIn.CustomTaskPanes.Count = 1 Then
        'Globals.ThisAddIn.CustomTaskPanes.Item(0).Visible = True
        'Else
        Dim actWindow = Globals.ThisAddIn.Application.ActiveWindow
        Dim ctpWindow = insTaskPane.Window
        Dim insTaskPaneForm = New TaskPaneView
        'If actWindow. ctpWindow Then
        insTaskPane = Globals.ThisAddIn.CustomTaskPanes.Add(insTaskPaneForm, "Sheets", actWindow)
            With insTaskPane
                .DockPosition = Office.MsoCTPDockPosition.msoCTPDockPositionFloating
                .Height = 500
                .Width = 400
                .DockPosition = Office.MsoCTPDockPosition.msoCTPDockPositionLeft
                .Width = 300
                .Visible = True
            End With
            insTaskPaneForm.SyncSheets()
        'End If
    End Sub
End Class