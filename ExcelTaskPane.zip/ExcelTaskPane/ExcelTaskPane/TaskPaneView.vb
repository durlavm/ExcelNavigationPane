﻿'Imports Microsoft.Office.Interop.Excel
'Imports Microsoft.Office.Tools
Public Class TaskPaneView

    Dim xlApp As Excel.Application
    Dim xlWorkBook As Excel.Workbook
    Dim xlWorkSheets As Excel.Worksheets
    Dim itmIndex As Integer
    Dim cntrI As Integer
    Dim shtSelected As String

    Friend Sub SyncSheets()
        listbox_shts.Items.Clear()
        xlApp = Globals.ThisAddIn.Application
        xlWorkBook = xlApp.ActiveWorkbook
        itmIndex = 0
        For Each Sheet In xlWorkBook.Worksheets
            Me.listbox_shts.Items.Add(Sheet.name)
            If Sheet.visible = True Then
                listbox_shts.SetItemChecked(itmIndex, True)
            End If
            itmIndex = itmIndex + 1
        Next
        With listbox_shts
            .IntegralHeight = False
            .Height = .Items.Count * .ItemHeight
            .IntegralHeight = True
        End With
    End Sub

    Private Sub listbox_shts_DoubleClick(sender As Object, e As EventArgs) Handles listbox_shts.DoubleClick, listbox_shts.MouseDoubleClick
        itmIndex = listbox_shts.Items.IndexOf(listbox_shts.SelectedItem)
        listbox_shts.SetItemChecked(itmIndex, True)
        shtSelected = listbox_shts.Items(itmIndex)
        xlApp = Globals.ThisAddIn.Application
        xlWorkBook = xlApp.ActiveWorkbook
        ' Show and Activate Sheet
        Try
            xlWorkBook.Worksheets(shtSelected).activate
            xlWorkBook.Worksheets(shtSelected).visible = True
        Catch ex As Exception
            MsgBox("Invalid action!")
        End Try
    End Sub

    Private Sub listbox_shts_ItemCheck(sender As Object, e As Windows.Forms.ItemCheckEventArgs) Handles listbox_shts.ItemCheck
        itmIndex = e.Index
        shtSelected = listbox_shts.Items(itmIndex)
        xlApp = Globals.ThisAddIn.Application
        xlWorkBook = xlApp.ActiveWorkbook
        If listbox_shts.GetItemChecked(itmIndex) = False Then
            ' Show sheet
            Try
                xlWorkBook.Worksheets(shtSelected).visible = True
            Catch ex As Exception
                MsgBox("Can't Show! Sheet not found!")
            End Try
        ElseIf listbox_shts.GetItemChecked(itmIndex) = True Then
            ' Hide Sheet
            Try
                xlWorkBook.Worksheets(shtSelected).visible = False
            Catch ex As Exception
                MsgBox("Can't Hide! Sheet not found!")
            End Try
        End If
    End Sub

    Private Sub btn_ShowAllSheets_Click(sender As Object, e As EventArgs) Handles btn_ShowAllSheets.Click
        xlApp = Globals.ThisAddIn.Application
        xlWorkBook = xlApp.ActiveWorkbook
        For Each Sheet In xlWorkBook.Worksheets
            Sheet.Visible = True
        Next
        SyncSheets()
    End Sub

    Private Sub btn_HideAllSheets_Click(sender As Object, e As EventArgs) Handles btn_HideAllSheets.Click
        xlApp = Globals.ThisAddIn.Application
        xlWorkBook = xlApp.ActiveWorkbook
        xlWorkBook.ActiveSheet.Visible = True
        For Each Sheet In xlWorkBook.Worksheets
            If Sheet.name <> xlWorkBook.ActiveSheet.name Then
                Sheet.Visible = False
            End If
        Next
        SyncSheets()
    End Sub

    Private Sub btn_Refresh_Click(sender As Object, e As EventArgs) Handles btn_RefreshSheets.Click
        SyncSheets()
    End Sub

    Private Sub btn_SortSheets_Click(sender As Object, e As EventArgs) Handles btn_SortSheets.Click
        listbox_shts.Items.Clear()
        xlApp = Globals.ThisAddIn.Application
        xlWorkBook = xlApp.ActiveWorkbook
        Dim shtList(xlWorkBook.Worksheets.Count - 1) As String
        Array.Clear(shtList, 0, shtList.Length)

        itmIndex = 0
        For Each Sheet In xlWorkBook.Worksheets
            shtList(itmIndex) = Sheet.names
            itmIndex = itmIndex + 1
        Next
        Array.Sort(shtList)
        For cntrI = 0 To itmIndex - 1
            Me.listbox_shts.Items.Add(shtList(cntrI))
            If xlWorkBook.Worksheets(shtList(cntrI)).visible = True Then
                listbox_shts.SetItemChecked(cntrI, True)
            End If
            cntrI = cntrI + 1
        Next
        With listbox_shts
            .IntegralHeight = False
            .Height = .Items.Count * .ItemHeight
            .IntegralHeight = True
        End With
    End Sub
End Class